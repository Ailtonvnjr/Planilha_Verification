### Libraries ###

import      pyautogui
import      pyscreeze
import      pandas
import      time

### Test Cases ###

class Open_Sanplat():
    def Login():
    

    Login()
Open_Sanplat()