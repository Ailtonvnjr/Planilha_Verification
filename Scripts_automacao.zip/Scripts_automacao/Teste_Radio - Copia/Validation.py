### Libraries ###

import      pyautogui
import      pyscreeze
import      time


### Variables ###




### Test Cases ###

class Elster():
    def click():
        
        

        time.sleep(2)
        pyautogui.click(107, 36)
        time.sleep(2)
        pyautogui.click(446, 170)

    click()
Elster()




