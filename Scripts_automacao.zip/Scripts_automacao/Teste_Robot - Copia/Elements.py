### Libraries ###

import      pyautogui
import      pyscreeze
import      pandas
import      time
import      sys




class Selecao:
    def Validation():
        pyautogui.doubleClick(78, 177)
        time.sleep(2)
        pyautogui.doubleClick(112, 194)
        time.sleep(2)
        pyautogui.click(63, 213)
        pyautogui.click(63, 250)
        time.sleep(3)
        pyautogui.doubleClick(112, 194)
    Validation()
Selecao()
